// Array of words
const words = ["apple", "banana", "cherry", "orange"];

let currentWord;
let score = 0;

// Function to start a new round
function startRound() {
  // Generate a random word
  const randomIndex = Math.floor(Math.random() * words.length);
  currentWord = words[randomIndex];

  // Create the placeholder word
  let placeholder = "";
  for (let i = 0; i < currentWord.length; i++) {
    // Replace some letters with underscores
    if (Math.random() < 0.5) {
      placeholder += currentWord[i];
    } else {
      placeholder += "_";
    }
  }

  // Display the incomplete word
  document.getElementById("word-display").textContent = placeholder;
}

// Function to check the player's answer
function checkAnswer() {
  const playerAnswer = document.getElementById("answer-input").value.toLowerCase();

  if (playerAnswer === currentWord) {
    score++;
    document.getElementById("score-display").textContent = "Score: " + score;
    alert("Correct answer!");
  } else {
    alert("Incorrect answer. Try again!");
  }

  // Start a new round
  startRound();
}

// Event listener for the submit button
document.getElementById("submit-button").addEventListener("click", checkAnswer);

// Start the game
startRound();
